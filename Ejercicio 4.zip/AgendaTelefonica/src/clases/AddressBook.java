/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import java.util.ArrayList;

/**
 *
 * @author pacov
 */
public class AddressBook {
   private int codigo;
   private String nombre;
   private String Apellido;
   private String Numero;
   private ArrayList<Numero> numeros;

    public AddressBook() {
        numeros = new ArrayList();
        
    }

    public AddressBook(int codigo, String nombre, String Apellido, ArrayList<Numero> numeros, String Numero) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.Apellido = Apellido;
        this.numeros = numeros;
        this.Numero = Numero;
    }

    public AddressBook(int codigo, String nombre, String Apellido, String Numero) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.Apellido = Apellido;
        this.Numero = Numero;
        numeros = new ArrayList();
    }

    public String getNumero() {
        return Numero;
    }

    public void setNumero(String Numero) {
        this.Numero = Numero;
    }

    
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return Apellido;
    }

    public void setApellido(String Apellido) {
        this.Apellido = Apellido;
    }

    public ArrayList<Numero> getNumeros() {
        return numeros;
    }

    public void setNumeros(ArrayList<Numero> numeros) {
        this.numeros = numeros;
    }

   


}
