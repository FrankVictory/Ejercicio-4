/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import java.io.*;
import java.util.ArrayList;

/**
 *
 * @author pacov
 */
public class Archivo {
    
    public void Grabar(String cadena){
        try{
        FileWriter archivo = new FileWriter("Datos.txt", true);
        try(BufferedWriter almacen = new BufferedWriter(archivo)){
        almacen.write(cadena + "\n");
        almacen.close();        
                }
        archivo.close();
        }catch(Exception ex){
            
        }
        }
    
    public ArrayList<String> Leer(){
        ArrayList<String> datos = new ArrayList<>();
        try{
            FileReader archivo = new FileReader("Datos.txt");
            BufferedReader lectura = new BufferedReader(archivo);
            String cadena;
            while ((cadena = lectura.readLine())!= null){
                datos.add(cadena);
            }
        }catch(Exception ex){}
        return datos;
    }
    }
